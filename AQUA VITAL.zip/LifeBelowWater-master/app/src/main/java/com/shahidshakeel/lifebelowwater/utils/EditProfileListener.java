package com.shahidshakeel.lifebelowwater.utils;

import com.shahidshakeel.lifebelowwater.model.Specie;

public interface EditProfileListener {
  void onProfileEdit(Specie specie);
}
