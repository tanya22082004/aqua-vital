package com.shahidshakeel.lifebelowwater.utils.recyclerview.species;

import com.shahidshakeel.lifebelowwater.model.Specie;

public interface OnSpecieClickListener {
  void onSpecieClick(int position);
}
