package com.shahidshakeel.lifebelowwater.utils;

public interface LogOutListener {
  void onLogoutClicked();
}
