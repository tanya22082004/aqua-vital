package com.shahidshakeel.lifebelowwater.utils;

public class Const {
  public static final String SHARED_PREFS_KEY = "SHARED_PREFS_CG3.0";
  public static final String AQUATIC_EXPERT = "AQUATIC_EXPERT";
}
