package com.shahidshakeel.lifebelowwater.utils;

public interface AddSpecieListener {
  void onAddSpecieRequest();
}
